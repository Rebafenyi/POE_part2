﻿namespace POE_P1;
class Program
{
    public static List<Recipe> recipes = new List<Recipe>();

    static void Main(string[] args)
    {
        // test code for errors
        try
        {
            // the start of
            welcomeMessage();
            introMessage();


            // the while loop
            bool shouldContinue = true;

            while (shouldContinue)
            {
                Console.WriteLine("\nEnter number of what you would like to do: \n1) Add A Recipe \n2) View List Of Recipes \n0) Exit");
                int choice = Int32.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    // generates the recipe
                    Recipe myRecipe = RecipeGenerator.GenereteNewEmptyRecipe();
                    recipes.Add(myRecipe);
                } else if (choice == 2)
                {
                    // exit loop used to show the recipes
                    shouldContinue = false;
                } else if (choice == 0)
                {
                    Exit(); // exits the program
                }

            } 

            // displays the recipes list
            Console.WriteLine("\nThe list of the recipes stored:");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            recipes = recipes.OrderBy(x => x.name).ToList();
            recipes.ForEach((r) =>
            {
                String line = (recipes.IndexOf(r) + 1) + " " + r.name;
                Console.WriteLine(line);
                
            });
            Console.Write("\nChoose a number: ");

            try
            {
                int number = Int32.Parse(Console.ReadLine()) - 1;
                Recipe selectedRecipe = recipes[number];
                selectedRecipe.DisplayRecipe();
                selectedRecipe.ShowCalories();

                // this method scales the recipe
                selectedRecipe.ScaleRecipe();

                // reset values if user wants to
                selectedRecipe.ResetValues();

                // exits the program
                Exit();
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }
        catch
        {
            Console.WriteLine("\nProgram  Has Crashed. Make Sure To Re-run It.");
        }
        
        
    }

    // programs methods
    public static void welcomeMessage()
    {
        Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
        Console.WriteLine("              WELCOME TO THE BIG RECIPE GROUND...                 ");
        Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
    }
    public static void introMessage()
    {
        Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
        Console.WriteLine("                 LETS GET COOKING !!!                ");
        Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
    }


    public static void Exit()
    {
        Console.WriteLine("\nExit Program? 1 For 'YES' 0 For 'NO'");
        int pick = Int32.Parse(Console.ReadLine());

        switch (pick)
        {
            case 1:
                Console.WriteLine("\nHave a great meal. Cheers ;-).");
                System.Environment.Exit(0);
                break;
            case 0:
                Console.WriteLine("\nThis is where we part ways.");
                break;
            default:
                Console.WriteLine("\nThe choice you have made is invalid. GoodBye!!!");
                break;
        }
    }

}