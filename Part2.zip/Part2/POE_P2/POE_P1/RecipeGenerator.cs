﻿using System;
namespace POE_P1
{
	public class RecipeGenerator
	{
        public static Recipe GenereteNewEmptyRecipe()
        {
            Recipe recipe = new Recipe()
            {
                ingredients = new List<Ingredient>(),
                steps = new List<string>()
            };
            

            // gets recipe name
            Console.Write("Enter Recipe Name: ");
            recipe.SetName(Console.ReadLine());

            // gets category
            Console.WriteLine("\nChoose Category: \n1). Jellof-Rice \n2). Salad \n3). Main-course \n4). Dessert \n5). Baked-Muffins \n6). Chicken-Soup");
            int pick1 = Int32.Parse(Console.ReadLine());

            // conditional switch cases
            switch (pick1)
            {
                case 1:
                    recipe.SetCategory("Jellof-Rice");
                    
                    break;
                case 2:
                    recipe.SetCategory("Salad");
                    break;
                case 3:
                    recipe.SetCategory("Main-course");
                    break;
                case 4:
                    recipe.SetCategory("Dessert");
                    break;
                case 5:
                    recipe.SetCategory("Baked-Muffins");
                    break;
                case 6:
                    recipe.SetCategory("Chicken-Soup");
                    break;
                default:
                    Console.WriteLine("Choose Valid Option.");
                    break;
            }

            // gets ingredient number
            Console.Write("\nEnter Number Of Ingredients: ");
            int numberOfIngredients = Int32.Parse(Console.ReadLine());

            recipe = AddIngredient(recipe, numberOfIngredients);

            // gets number of steps
            Console.Write("\nEnter Number Of Steps: ");
            int numberOfSteps = Int32.Parse(Console.ReadLine());
            recipe = AddSteps(recipe, numberOfSteps);

            return recipe;
        }

        //method to add step
        public static Recipe AddSteps(Recipe recipe, int noOfSteps)
        {
            recipe.steps = new List<string>();
            for (int i = 0; i < noOfSteps; i++)
            {
                Console.Write("\nStep" + (i+1)+": ");
                recipe.steps.Add(Console.ReadLine());
            }
            Console.WriteLine("\nSteps stored!");

            return recipe;
        }

        // method that adds ingredient
        private static Recipe AddIngredient(Recipe recipe, int noOfIngredients)
        {
            int count = 1; // keeps track of items added to list
            recipe.ingredients = new List<Ingredient>();

            // ingredient is added
            for (int i = 0; i < noOfIngredients; i++)
            {
                Ingredient ingredient = new Ingredient(); 

                Console.Write("\nIngredient " + count + " - Enter Name: ");
                ingredient.SetName(Console.ReadLine());

                Console.WriteLine("\nQuantity? (Numeric Value)");
                ingredient.SetQuantity(Double.Parse(Console.ReadLine()));

                Console.WriteLine("\nUnits Of Measurements: \n1). grams \n2). ml \n3). teaspoon \n4). tablespoon \n5). cup");
                int pick2 = Int32.Parse(Console.ReadLine());

                // conditional switch cases for measurement units
                switch (pick2)
                {
                    case 1:
                        ingredient.unitOfMeasurement = "gram(s)";
                        break;
                    case 2:
                        ingredient.unitOfMeasurement = "ml(s)";
                        break;
                    case 3:
                        ingredient.unitOfMeasurement = "teaspoon(s)";
                        break;
                    case 4:
                        ingredient.unitOfMeasurement = "tablespoon(s)";
                        break;
                    case 5:
                        ingredient.unitOfMeasurement = "cup(s)";
                        break;
                    default:
                        Console.WriteLine("Choose Valid Option.");
                        break;
                }

                Console.Write("\nCalories: ");
                ingredient.calories = Double.Parse(Console.ReadLine());

                Console.WriteLine("\nFood Group: \n1) Vegetables \n2) Fruits \n3) Grains \n4) Protein \n5) Dairy \n6) Fat \n7) Added Sugar \n8) Beverages");
                int pick3 = Int32.Parse(Console.ReadLine());

                // conditional switch cases that categorises foodgroup of ingredient
                switch (pick3)
                {
                    case 1:
                        ingredient.foodGroup = "Vegetables";
                        break;
                    case 2:
                        ingredient.foodGroup = "Fruits";
                        break;
                    case 3:
                        ingredient.foodGroup = "Grains";
                        break;
                    case 4:
                        ingredient.foodGroup = "Protein";
                        break;
                    case 5:
                        ingredient.foodGroup = "Dairy";
                        break;
                    case 6:
                        ingredient.foodGroup = "Fat";
                        break;
                    case 7:
                        ingredient.foodGroup = "Added Sugar";
                        break;
                    case 8:
                        ingredient.foodGroup = "Beverages";
                        break;
                    default:
                        Console.WriteLine("Choose a Valid Option.");
                        break;
                }

                Console.WriteLine("\nIngredient Has Been Added!");

                recipe.ingredients.Add(ingredient);

                count++;
            }

            return recipe;

        }
    }
}

