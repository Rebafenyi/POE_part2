﻿using System;
namespace POE_P1
{
	public class Ingredient
	{
		//Variables of recipe club
		public string name;
		public double quantity;
		public string unitOfMeasurement;
        public double calories;
        public string foodGroup;

       
        
        // the set methods
        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetQuantity(double quantity)
        {
            this.quantity = quantity;
        }
        public void SetUnits(string units)
        {
            this.unitOfMeasurement = units;
        }
        public void SetCalories(double calories)
        {
            this.calories = calories;
        }
        public void SetFoodGroup(string foodGroup)
        {
            this.foodGroup = foodGroup;
        }

        // the get methods
        public string GetName()
        {
            return name;
        }
        public double GetQuantity()
        {
            return quantity;
        }
        public string GetUnits()
        {
            return unitOfMeasurement;
        }
        public double GetCalories()
        {
            return calories;
        }
        public string GetFoodGroup()
        {
            return foodGroup;
        }


    }
}

