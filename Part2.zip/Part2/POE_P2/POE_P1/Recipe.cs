﻿using System;
namespace POE_P1
{
	public class Recipe
	{
        // attributes
        public string name;
        public int numberOfIngredients;
        private string category;
		private int numberOfSteps;
        public List<String> steps;
        public List<Ingredient> ingredients;

		// constructor not used
        public Recipe() {}

		// set methods
		public void SetName(string name) { this.name = name; }
        public void SetNumberOfIngredients(int numberOfIngredients) { this.numberOfIngredients = numberOfIngredients; }
        public void SetCategory(string category) { this.category = category; }
        public void SetNumberOfSteps(int steps) { this.numberOfSteps = steps; }

        // get methods
        public string GetName() { return name; }
        public int GetNumberOfIngredients() { return numberOfIngredients; }
        public string GetCategory() { return category; }
        public int GetNumberOfSteps() { return numberOfSteps; }

        // 2) Programs methods
        public void DisplayRecipe()
        {
            //Recipe recipe = this;
            Console.WriteLine("\n\n=========================================================");
            Console.WriteLine("Recipe Name: \t\t\t\t" + name.ToUpper());
            Console.WriteLine("Category: \t\t\t\t" + category.ToUpper());
            Console.WriteLine("Number of Ingredients: \t\t\t" + ingredients.Count);
            Console.WriteLine("Number of Steps: \t\t\t" + steps.Count);

            Console.WriteLine("\nINGREDIENTS: ");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            

            // loop
            ingredients.ToString();
            PrintIngredients();

            Console.WriteLine("\nSTEPS: ");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            // loop
            steps.ToString();
            PrintSteps();

            Console.WriteLine("\n=========================================================");

        } 


        // print methods
        public void PrintIngredients()
        {
            foreach (Ingredient item in ingredients)
            {
                int count = 1;

                Console.WriteLine(item.GetQuantity() + " " + item.GetUnits() + " of " + item.GetName());

                count++;
            }
        }

        public void PrintSteps()
        {
            int count = 1; // keeps count

            foreach (String step in steps)
            {

                Console.WriteLine(count + ". " + step);

                count++;
            }
        }

        // calculate and show
        public void ShowCalories()
        {
            //
            double cals = 0;
            ingredients.ForEach((ing) =>
            {
                cals += ing.calories;
            });
            cals = Math.Round(cals, 2);
            Console.WriteLine("Total Number of Calories: "+ cals);
            Console.WriteLine("\nThe Calories are "+ (  (cals >= 300) ? " Above 300" :  " Below 300")   ); //short-hand if statement
            Console.WriteLine("=========================================================");
        }

        // manipulate recipe methods
        public void ScaleRecipe()
        {
            Console.WriteLine("\nDo you wish to scale recipe " + name.ToUpper() + "? 1 For 'YES' 0 For 'NO'");
            int num = Int32.Parse(Console.ReadLine());

            // conditions
            if (num == 1)
            {
                Console.WriteLine("\nScale by: \n1) 0.5 (Half) \n2) 2 (Double) \n3) (Triple)");
                int num2 = Int32.Parse(Console.ReadLine());


                // switch
                switch (num2)
                {
                    case 1:
                        Divide();
                        break;
                    case 2:
                        MultiplyTwice();
                        break;
                    case 3:
                        MultiplyTrice();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice.");
                        break;
                }   
                
            }
            else if (num == 0)
            {
                Console.WriteLine("\nQuantities remain unchanged.");
            }
            else Console.WriteLine("\nInvalid Choice");
        }

        // maths methods
        public void Divide()
        {
            Console.WriteLine("\nNew Quantities:".ToUpper());
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            foreach (Ingredient item in ingredients)
            {
                double answer = item.GetQuantity() / 0.5;
                Console.WriteLine(answer + " " + item.GetUnits() + " of " + item.GetName()); // print the value but doen't change the original
            }

        }
        public void MultiplyTwice()
        {
            Console.WriteLine("\nNew Quantities:".ToUpper());
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            foreach (Ingredient item in ingredients)
            {
                double answer = item.GetQuantity() * 2;
                Console.WriteLine(answer + " " + item.GetUnits() + " of " + item.GetName());
            }

        }
        public void MultiplyTrice()
        {
            Console.WriteLine("\nNew Quantities:".ToUpper());
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            ingredients.ForEach((ing) =>
            {
                double answer = ing.GetQuantity() * 3;
                Console.WriteLine(answer + " " + ing.GetUnits() + " of " + ing.GetName());
            });

            
        }

        // reset values
        public void ResetValues()
        {
            Console.WriteLine("\nDo you wish to reset the values? 1 For 'YES' 0 For 'NO'");
            int pick = Int32.Parse(Console.ReadLine());

            switch (pick)
            {
                case 1:
                    Console.WriteLine("\n");
                    PrintIngredients();
                    break;
                case 0:
                    Console.WriteLine("\nValues Remain Unchanged.");
                    break;
                default:
                    Console.WriteLine("\nInvalid Choice.");
                    break;
            }
        }

    }
}

